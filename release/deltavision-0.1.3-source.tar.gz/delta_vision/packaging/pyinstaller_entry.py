# Entry wrapper for PyInstaller to locate the module properly
from delta_vision.entry_points import main

if __name__ == '__main__':
    main()
