from __future__ import annotations

# Global performance guardrails (tweak as needed)
MAX_FILES: int = 5000
MAX_PREVIEW_CHARS: int = 500
MAX_RENDER_LINES: int = 5000
